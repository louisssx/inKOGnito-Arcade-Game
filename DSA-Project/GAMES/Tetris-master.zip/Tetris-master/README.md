# Tetris
Tetris is a classic game based on python.
### Screenshot 
![demo](https://user-images.githubusercontent.com/22257930/85377927-705ac300-b557-11ea-9832-27ea33703292.png)
### Information About Files
How to play game : to increase your points match the same colour
- matris.py : is the main file which you have to run
- scores.py : calculate the points
- tetrominoes.py : for colour and shape

### Module Used
GUI Module Used : Tkinter
### For external libraries
pip install pygame

Developed By **Sahil Janbandhu**
