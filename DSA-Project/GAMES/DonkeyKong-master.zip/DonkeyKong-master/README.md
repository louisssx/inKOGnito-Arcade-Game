# DonkeyKong
A simplified remake of the retro Donkey Kong Arcade Game.
![](https://i2.wp.com/pythonprogramming.altervista.org/wp-content/uploads/2021/08/image-30.png?w=800&ssl=1)

https://pythonprogramming.altervista.org/donkey-kong-and-pygame-what-a-match/
https://youtu.be/0NCkcB0fX-8

![](https://pythonprogramming.altervista.org/wp-content/uploads/2021/08/image-34.png)
